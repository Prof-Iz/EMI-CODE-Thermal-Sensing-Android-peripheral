# AP3216_WE
Arduino library for the AP3216C module (CJMCU 3216). 

In order to find out how the library works please look into the examples and the list of public functions.

Wiring for Arduino can be found in AP3216_Module_Wiring.png

Further details can be found on http://wolles-elektronikkiste.de/ap3216-cjmcu-3216 (sorry, only German language)

Have fun!
